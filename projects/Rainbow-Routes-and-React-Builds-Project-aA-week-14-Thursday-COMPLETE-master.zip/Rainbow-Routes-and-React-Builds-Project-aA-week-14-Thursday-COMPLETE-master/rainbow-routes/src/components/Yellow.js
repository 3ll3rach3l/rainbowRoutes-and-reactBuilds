import React from 'react';

const Yellow = () => (
  <div>
    <h2 className='yellow'>Yellow</h2>
  </div>
)

export default Yellow;
