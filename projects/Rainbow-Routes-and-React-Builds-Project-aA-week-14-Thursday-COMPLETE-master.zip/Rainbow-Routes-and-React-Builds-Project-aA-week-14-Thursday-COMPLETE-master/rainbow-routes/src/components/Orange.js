import React from 'react';

const Orange = () => (
  <div>
    <h2 className='orange'>Orange</h2>
  </div>
)

export default Orange;
