import React from 'react';
import { Route, NavLink } from 'react-router-dom';
import Red from './Red';
import Green from './Green';
import Blue from './Blue';
import Violet from './Violet';

const Rainbow = () => (
  <div>
    <h1>RAINBOW ROUTER!</h1>
    <div id ='rainbow'>
      <Route path='/red' component={Red} />
      <NavLink exact to='/red' activeClassName='parent-active'>RED ONLY</NavLink>
      <Route path='/green' component={Green} />
      <NavLink to='/green' activeClassName='parent-active'>GREEN</NavLink>
      <Route path='/blue' component={Blue} />
      <NavLink exact to='/blue' activeClassName='parent-active'>BLUE ONLY</NavLink>
      <Route path='/violet' component={Violet} />
      <NavLink to='/violet' activeClassName='parent-active'>VIOLET</NavLink>
      {/* <Route path='/' component={Rainbow}/> */}
    </div>
  </div>
)

export default Rainbow;
