import React from 'react';

const Indigo = () => (
  <div>
    <h2 className='indigo'>Indigo</h2>
  </div>
)

export default Indigo;
