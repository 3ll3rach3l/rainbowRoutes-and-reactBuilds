import React from 'react';
import {Route, NavLink} from 'react-router-dom';
import Orange from './Orange';
import Yellow from './Yellow';

const Red = () => (
  <div>
    <h2 className="red">Red</h2>
    <Route path='/red/orange' component={Orange}></Route>
        <NavLink to='/red/orange'>ORANGE</NavLink>
    <Route path='/red/yellow' component={Yellow} />
        <NavLink to='/red/yellow'>YELLOW</NavLink>
  </div>
);

export default Red;
