import React from 'react';

const Green = () => (
  <div>
    <h2 className='green'> Green</h2>
  </div>
)

export default Green;
