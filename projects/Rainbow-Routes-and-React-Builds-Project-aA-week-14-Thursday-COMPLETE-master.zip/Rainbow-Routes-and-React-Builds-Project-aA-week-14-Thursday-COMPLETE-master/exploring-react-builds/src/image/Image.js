import React from 'react';
import cat from './IMG_5582.jpg';
import './Image.css'

console.log(cat);

function Image() {
  return (
    <div>
      <img src={cat} className='cat' alt='Cat' />
      <div className='cat'></div>
    </div>

  )
}

export default Image;
