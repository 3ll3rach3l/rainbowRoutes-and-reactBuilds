import React from 'react';
import { Route, NavLink } from 'react-router-dom';
import Indigo from './Indigo';

const Blue = () => (
  <div>
    <h2 className='blue'>Blue</h2>
    <Route path='/blue/indigo' component={Indigo} />
    <NavLink to='/blue/indigo'>ADD INDIGO</NavLink>
    </div>
)

export default Blue;
